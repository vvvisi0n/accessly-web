"use client";
import { useState } from "react";

export function useAIScan() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);

  const runScan = async (area: string, context: string) => {
    setLoading(true);
    try {
      const res = await fetch("/api/ai/scan", {
        method: "POST",
        body: JSON.stringify({ area, context }),
      });
      const data = await res.json();
      setResult(data);
    } catch (error) {
      console.error("Scan error:", error);
    } finally {
      setLoading(false);
    }
  };

  return { loading, result, runScan };
}
