"use client";

import { useEffect, useState } from "react";
import useVoiceNav, { NavPlace } from "@/hooks/useVoiceNav";
import useVoiceCommands from "@/hooks/useVoiceCommands";
import useConversationalAI from "@/hooks/useConversationalAI";
import useAIContextMemory from "@/hooks/useAIContextMemory";
import useLiveLocation from "@/hooks/useLiveLocation";
import useNearbyAccessiblePlaces from "@/hooks/useNearbyAccessiblePlaces";
import useProximityFeedback from "@/hooks/useProximityFeedback";
import useMapTheme from "@/hooks/useMapTheme";
import useDeviceSensors from "@/hooks/useDeviceSensors";
import useAdaptiveVoice from "@/hooks/useAdaptiveVoice";
import useEnvironmentAwareness from "@/hooks/useEnvironmentAwareness";
import useEmotionDetection, { Emotion } from "@/hooks/useEmotionDetection";
import useUserMemory from "@/hooks/useUserMemory";
import useAdaptivePersonality from "@/hooks/useAdaptivePersonality";
import useUserProfile from "@/hooks/useUserProfile";
import useOfflineRecovery from "@/hooks/useOfflineRecovery";
import useObstacleAvoidance from "@/hooks/useObstacleAvoidance";
import AccessibleMap from "@/components/AccessibleMap";

export default function VoiceNav({ places }: { places: NavPlace[] }) {
  const {
    steps,
    index,
    isSpeaking,
    isPaused,
    start,
    stop,
    pause,
    resume,
    next,
    prev,
    speakCurrent,
    autoAdvance,
    setAutoAdvance,
    proximity,
    offCourse,
  } = useVoiceNav(places);

  // 🧠 Context, GPS, and Theme
  const { memory, remember } = useAIContextMemory();
  const { coords } = useLiveLocation();
  const { theme, setTheme } = useMapTheme();

  // ♿ Nearby accessible places
  const { places: nearbyPlaces, loading: nearbyLoading } =
    useNearbyAccessiblePlaces(coords);

  // 🎧 Voice commands
  const { listening, setListening } = useVoiceCommands({
    onNext: next,
    onPrev: prev,
    onRepeat: speakCurrent,
    onStart: start,
    onPause: pause,
    onResume: resume,
    onStop: stop,
  });

  // 🤖 Conversational AI
  const [conversationMode, setConversationMode] = useState(false);
  const { processQuery, thinking } = useConversationalAI({
    onCommand: (cmd) => console.log("Voice Command:", cmd),
    onResponse: (reply) => {
      remember("User", reply);
      console.log("AI Reply:", reply);
    },
  });

  // 🔔 Proximity Feedback
  const [proximityAlerts, setProximityAlerts] = useState(true);
  useProximityFeedback({
    enabled: proximityAlerts,
    points: (nearbyPlaces || []).map((p) => ({
      id: p.id,
      name: p.name,
      lat: p.lat,
      lng: p.lng,
      category: p.category,
    })),
    coords: coords ? { lat: coords.lat, lng: coords.lng } : null,
    vibrateAt: [50, 20],
    minBeepIntervalMs: 500,
    maxBeepIntervalMs: 2200,
    nearestOnly: true,
  });

  // 📱 Motion Sensor Awareness
  const [motionActive, setMotionActive] = useState(false);
  const { enabled, setEnabled } = useDeviceSensors({
    onShake: () => {
      console.log("📱 Shake detected — repeating navigation instruction");
      speakCurrent();
    },
    onTilt: (tiltX, tiltY) => {
      if (tiltX > 25) next();
      if (tiltX < -25) prev();
    },
  });
  useEffect(() => setEnabled(motionActive), [motionActive, setEnabled]);

  // 🔊 Adaptive Voice
  const { speak } = useAdaptiveVoice({
    language: "en-US",
    defaultRate: 1,
    defaultPitch: 1,
  });

  // 🌍 Environment Awareness
  const env = useEnvironmentAwareness();
  useEffect(() => {
    if (env.brightness === "dim" && theme !== "dark") setTheme("dark");
    if (env.brightness === "bright" && theme === "dark") setTheme("light");
  }, [env.brightness, theme, setTheme]);

  useEffect(() => {
    if (env.noiseLevel > 80) {
      speak({
        text: "It's a bit noisy around you. I'll speak louder for clarity.",
        context: "alert",
      });
    }
  }, [env.noiseLevel, speak]);

  useEffect(() => {
    if (env.weather) {
      if (["61", "63", "65"].includes(env.weather)) {
        speak({
          text: "It's raining — please be careful on wet surfaces.",
          context: "alert",
        });
      }
      if (env.temperature && env.temperature < 5) {
        speak({
          text: "It’s cold outside — move carefully and stay warm.",
          context: "normal",
        });
      }
    }
  }, [env.weather, env.temperature, speak]);

  // 😊 Emotion Detection
  const [currentEmotion, setCurrentEmotion] = useState<Emotion>("neutral");
  useEmotionDetection({
    onEmotionChange: (emotion) => {
      setCurrentEmotion(emotion);
      console.log("🧠 Detected Emotion:", emotion);
      switch (emotion) {
        case "frustrated":
          speak({
            text: "I sense a little frustration. Don’t worry, we’ll sort this out together.",
            context: "calm",
          });
          break;
        case "happy":
          speak({
            text: "That’s the spirit! You’re doing great.",
            context: "approaching",
          });
          break;
        case "calm":
          speak({
            text: "Everything feels steady. Let’s keep going.",
            context: "normal",
          });
          break;
        default:
          break;
      }
    },
  });

  // 💾 Long-Term Memory
  const { prefs, updatePref } = useUserMemory();
  useEffect(() => {
    if (prefs.theme) setTheme(prefs.theme);
    if (prefs.proximityAlerts !== undefined)
      setProximityAlerts(prefs.proximityAlerts);
    if (prefs.motionEnabled !== undefined) setMotionActive(prefs.motionEnabled);
  }, [prefs, setTheme]);
  useEffect(() => updatePref("theme", theme), [theme]);
  useEffect(() => updatePref("proximityAlerts", proximityAlerts), [proximityAlerts]);
  useEffect(() => updatePref("motionEnabled", motionActive), [motionActive]);

  // 🧬 Adaptive Personality
  const { mode, adapt } = useAdaptivePersonality();
  useEffect(() => {
    const success = offCourse ? 0.5 : 1;
    adapt(currentEmotion, success);
  }, [currentEmotion, offCourse]);

  useEffect(() => {
    if (mode === "friendly")
      speak({ text: "Hey there! Great to see you again.", context: "normal" });
    if (mode === "calm")
      speak({ text: "Welcome back. Let’s move at your pace today.", context: "normal" });
    if (mode === "motivational")
      speak({ text: "Ready to roll? Let’s make this journey awesome!", context: "approaching" });
    if (mode === "professional")
      speak({ text: "Hello. Your route and preferences are restored.", context: "normal" });
  }, [mode]);

  // 👤 Multi-User Profile Integration
  const { profile, profiles, switchProfile, saveProfile, syncToCloud } = useUserProfile();

  // Apply profile prefs on load
  useEffect(() => {
    if (profile.preferences.theme) setTheme(profile.preferences.theme);
    if (profile.preferences.proximityAlerts !== undefined)
      setProximityAlerts(profile.preferences.proximityAlerts);
    if (profile.preferences.motionEnabled !== undefined)
      setMotionActive(profile.preferences.motionEnabled);
  }, [profile, setTheme]);

  // Save updates automatically
  useEffect(() => {
    saveProfile({
      ...profile,
      preferences: {
        ...profile.preferences,
        theme,
        proximityAlerts,
        motionEnabled: motionActive,
        personality: mode,
      },
    });
  }, [theme, proximityAlerts, motionActive, mode]);

  // Auto cloud sync every 5 minutes
  useEffect(() => {
    const interval = setInterval(() => syncToCloud(), 300000);
    return () => clearInterval(interval);
  }, [syncToCloud]);

  // 🌐 Offline Recovery
  const { isOnline } = useOfflineRecovery({
    key: "accessly-route-cache",
    data: { places, nearbyPlaces },
    onRestore: (cached) => {
      speak({
        text: "Connection restored. Resuming from cached route.",
        context: "normal",
      });
      console.log("🧭 Restored cached data:", cached);
    },
    onStatusChange: (online) => {
      if (!online) {
        speak({
          text: "You’re offline — using saved route data.",
          context: "alert",
        });
      }
    },
  });

  // 🚧 Adaptive Obstacle Avoidance
  const [rerouting, setRerouting] = useState(false);
  const { obstacle } = useObstacleAvoidance({
    coords,
    onObstacleDetected: (o) => {
      setRerouting(true);
      speak({
        text: `Obstacle detected ahead — ${o.type === "stair
