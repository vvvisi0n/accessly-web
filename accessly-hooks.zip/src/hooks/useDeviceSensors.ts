"use client";

import { useEffect, useState } from "react";
import useVoiceNav, { NavPlace } from "@/hooks/useVoiceNav";
import useVoiceCommands from "@/hooks/useVoiceCommands";
import useConversationalAI from "@/hooks/useConversationalAI";
import useAIContextMemory from "@/hooks/useAIContextMemory";
import useLiveLocation from "@/hooks/useLiveLocation";
import useNearbyAccessiblePlaces from "@/hooks/useNearbyAccessiblePlaces";
import useProximityFeedback from "@/hooks/useProximityFeedback";
import useMapTheme from "@/hooks/useMapTheme";
import useDeviceSensors from "@/hooks/useDeviceSensors";
import AccessibleMap from "@/components/AccessibleMap";

export default function VoiceNav({ places }: { places: NavPlace[] }) {
  const {
    steps,
    index,
    isSpeaking,
    isPaused,
    start,
    stop,
    pause,
    resume,
    next,
    prev,
    speakCurrent,
    autoAdvance,
    setAutoAdvance,
    proximity,
    offCourse,
  } = useVoiceNav(places);

  // 🧠 Context + GPS + Theme
  const { memory, remember } = useAIContextMemory();
  const { coords } = useLiveLocation();
  const { theme, setTheme } = useMapTheme();

  // ♿ Nearby accessible places
  const { places: nearbyPlaces, loading: nearbyLoading } =
    useNearbyAccessiblePlaces(coords);

  // 🎧 Voice commands
  const { listening, setListening } = useVoiceCommands({
    onNext: next,
    onPrev: prev,
    onRepeat: speakCurrent,
    onStart: start,
    onPause: pause,
    onResume: resume,
    onStop: stop,
  });

  // 🤖 Conversational AI
  const [conversationMode, setConversationMode] = useState(false);
  const { processQuery, thinking } = useConversationalAI({
    onCommand: (cmd) => console.log("Voice Command:", cmd),
    onResponse: (reply) => {
      remember("User", reply);
      console.log("AI Reply:", reply);
    },
  });

  // 🔔 Proximity Feedback
  const [proximityAlerts, setProximityAlerts] = useState(true);
  useProximityFeedback({
    enabled: proximityAlerts,
    points: (nearbyPlaces || []).map((p) => ({
      id: p.id,
      name: p.name,
      lat: p.lat,
      lng: p.lng,
      category: p.category,
    })),
    coords: coords ? { lat: coords.lat, lng: coords.lng } : null,
    vibrateAt: [50, 20],
    minBeepIntervalMs: 500,
    maxBeepIntervalMs: 2200,
    nearestOnly: true,
  });

  // 📱 Multi-Sensor Motion Awareness
  const [motionActive, setMotionActive] = useState(false);
  const { enabled, setEnabled } = useDeviceSensors({
    onShake: () => {
      console.log("📱 Shake detected — repeating navigation instruction");
      speakCurrent();
    },
    onTilt: (tiltX, tiltY) => {
      if (tiltX > 25) {
        console.log("↕ Tilt Forward — next waypoint");
        next();
      }
      if (tiltX < -25) {
        console.log("↕ Tilt Backward — previous waypoint");
        prev();
      }
      if (tiltY > 25) console.log("↔ Tilt Right — potential map pan right");
      if (tiltY < -25) console.log("↔ Tilt Left — potential map pan left");
    },
    onMotion: (accel) => {
      if (accel > 15) console.log("Motion intensity:", accel.toFixed(2));
    },
  });

  useEffect(() => {
    setEnabled(motionActive);
  }, [motionActive, setEnabled]);

  if (!places || places.length < 2) return null;

  return (
    <div className="bg-white border border-gray-200 rounded-xl p-4 shadow-sm">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-3 gap-2">
        <h4 className="font-semibold text-lg">🔊 Voice Navigation</h4>

        <div className="flex items-center gap-3 flex-wrap text-sm">
          <label className="flex items-center gap-1">
            <input
              type="checkbox"
              checked={autoAdvance}
              onChange={() => setAutoAdvance((v) => !v)}
              className="accent-purple-600"
            />
            Auto-Advance
          </label>

          <label className="flex items-center gap-1">
            <input
              type="checkbox"
              checked={listening}
              onChange={() => setListening((v) => !v)}
              className="accent-indigo-600"
            />
            🎙 Commands
          </label>

          <label className="flex items-center gap-1">
            <input
              type="checkbox"
              checked={conversationMode}
              onChange={() => setConversationMode((v) => !v)}
              className="accent-rose-600"
            />
            🧠 Conversational
          </label>

          <label className="flex items-center gap-1">
            <input
              type="checkbox"
              checked={proximityAlerts}
              onChange={() => setProximityAlerts((v) => !v)}
              className="accent-emerald-600"
            />
            🔔 Proximity
          </label>

          <label className="flex items-center gap-1">
            <input
              type="checkbox"
              checked={motionActive}
              onChange={() => setMotionActive((v) => !v)}
              className="accent-orange-600"
            />
            📱 Motion
          </label>

          {/* 🌗 Map Theme Selector */}
          <select
            value={theme}
            onChange={(e) => setTheme(e.target.value as any)}
            className="border border-gray-300 rounded-md px-2 py-1 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            aria-label="Map Theme Selector"
          >
            <option value="light">☀ Light</option>
            <option value="dark">🌙 Dark</option>
            <option value="high-contrast">🌓 High Contrast</option>
          </select>
        </div>
      </div>

      {/* Status Indicators */}
      {proximity !== null && (
        <div className="text-xs text-gray-500 mb-1">
          Distance to next waypoint: {Math.round(proximity)} m
        </div>
      )}
      {offCourse && (
        <div className="text-xs text-red-600 mb-2">
          ⚠️ Off route — recalculating…
        </div>
      )}
      {thinking && (
        <div className="text-xs text-blue-500 mb-2 animate-pulse">
          🤔 Accessly is thinking…
        </div>
      )}
      {coords && (
        <div className="text-xs text-gray-400 mb-2">
          📍 lat: {coords.lat.toFixed(4)}, lng: {coords.lng.toFixed(4)}
        </div>
      )}

      {/* Map Preview */}
      {coords && (
        <div className="mb-4">
          <AccessibleMap
            places={places}
            center={{ lat: coords.lat, lng: coords.lng }}
            selectedPlaceId={places[index]?.id}
            onPlaceSelect={(id) => console.log("Selected:", id)}
            showRoute={true}
            showAccessibility={true}
            nearbyPlaces={nearbyPlaces}
          />
          {nearbyLoading && (
            <div className="text-xs text-gray-500 mt-1 animate-pulse">
              🔄 Loading nearby accessible places…
            </div>
          )}
        </div>
      )}

      {/* Manual Controls */}
      <div className="flex flex-wrap gap-2 mb-3">
        <button
          onClick={start}
          className="px-3 py-1.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          Start
        </button>

        {!isPaused ? (
          <button
            onClick={pause}
            className="px-3 py-1.5 bg-gray-200 rounded-lg hover:bg-gray-300"
          >
            Pause
          </button>
        ) : (
          <button
            onClick={resume}
            className="px-3 py-1.5 bg-gray-200 rounded-lg hover:bg-gray-300"
          >
            Resume
          </button>
        )}

        <button
          onClick={stop}
          className="px-3 py-1.5 bg-gray-200 rounded-lg hover:bg-gray-300"
        >
          Stop
        </button>

        <button
          onClick={prev}
          className="px-3 py-1.5 bg-gray-200 rounded-lg hover:bg-gray-300"
        >
          ◀ Prev
        </button>
        <button
          onClick={next}
          className="px-3 py-1.5 bg-gray-200 rounded-lg hover:bg-gray-300"
        >
          Next ▶
        </button>

        <button
          onClick={speakCurrent}
          className="px-3 py-1.5 bg-gray-200 rounded-lg hover:bg-gray-300"
        >
          🔁 Repeat
        </button>

        {conversationMode && (
          <button
            onClick={() => processQuery("What’s nearby?")}
            className="px-3 py-1.5 bg-rose-500 text-white rounded-lg hover:bg-rose-600"
          >
            🎤 Ask AI
          </button>
        )}
      </div>

      {/* Step List */}
      <ol className="space-y-2 text-sm">
        {steps.map((s, i) => (
          <li
            key={`${s.fromName}-${s.toName}-${i}`}
            className={`p-2 rounded-lg border ${
              i === index ? "border-blue-400 bg-blue-50" : "border-gray-200"
            }`}
          >
            <div className="font-medium">
              {i + 1}. {s.fromName} → {s.toName}
            </div>
            <div className="text-gray-600">{s.summary}</div>
          </li>
        ))}
      </ol>

      {/* Status Footers */}
      {isSpeaking && (
        <div className="mt-2 text-xs text-blue-600">Speaking …</div>
      )}
      {conversationMode && (
        <div className="mt-1 text-xs text-rose-600">
          🧠 Conversational mode — ask “What’s
